'use strict';
// Intentionally empty. LifeWise requires no Node, Electron, or IPC bridge.
