'use strict';
const { app, BrowserWindow, Menu, session, shell, dialog } = require('electron');
const path = require('node:path');
const { MEMBER_URL, classifyNavigation } = require('./navigation');
let mainWindow;
let quitting = false;
let errorDialogOpen = false;
const grants = new Set();
app.setName('LifeWise');
const singleInstance = app.requestSingleInstanceLock();
if (!singleInstance) app.quit();
else {
  app.on('second-instance', () => {
    if (!mainWindow) return;
    if (mainWindow.isMinimized()) mainWindow.restore();
    mainWindow.show();
    mainWindow.focus();
  });
  app.whenReady().then(() => {
    if (process.platform === 'win32') app.setAppUserModelId('com.lifewiseapp.desktop');
    const memberSession = session.fromPartition('persist:lifewise-member');
    memberSession.setPermissionCheckHandler((contents, permission, origin) =>
      contents === mainWindow?.webContents && classifyNavigation(origin) === 'internal' && grants.has(permission));
    memberSession.setPermissionRequestHandler(async (contents, permission, callback, details) => {
      if (contents !== mainWindow?.webContents || classifyNavigation(contents.getURL()) !== 'internal' ||
          classifyNavigation(details.requestingUrl || contents.getURL()) !== 'internal' ||
          !['media', 'geolocation'].includes(permission)) return callback(false);
      if (grants.has(permission)) return callback(true);
      const label = permission === 'media' ? 'camera or microphone' : 'location';
      try {
        const { response } = await dialog.showMessageBox(mainWindow, {
          type: 'question', title: 'LifeWise permission',
          message: `Allow LifeWise to use your ${label}?`,
          detail: 'Only allow this if you just started a feature that needs it. This choice lasts until you quit LifeWise.',
          buttons: ['Not now', 'Allow'], defaultId: 0, cancelId: 0
        });
        if (response === 1) grants.add(permission);
        callback(response === 1);
      } catch { callback(false); }
    });
    Menu.setApplicationMenu(process.platform === 'darwin' ? Menu.buildFromTemplate([
      { label: 'LifeWise', submenu: [{ role: 'about' }, { type: 'separator' }, { role: 'hide' }, { role: 'hideOthers' }, { role: 'unhide' }, { type: 'separator' }, { role: 'quit' }] },
      { role: 'editMenu' },
      { label: 'View', submenu: [{ role: 'reload' }, { role: 'resetZoom' }, { role: 'zoomIn' }, { role: 'zoomOut' }, { role: 'togglefullscreen' }] },
      { role: 'windowMenu' }
    ]) : null);
    createWindow();
  });
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
  app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
  app.on('before-quit', () => { quitting = true; });
  app.on('will-quit', () => {
    // Persistent Chromium cookies and local storage remain in the same named partition.
    session.fromPartition('persist:lifewise-member').flushStorageData();
  });
}
function openExternal(raw) {
  if (classifyNavigation(raw) === 'external') shell.openExternal(raw).catch(() => {});
}
function createWindow() {
  mainWindow = new BrowserWindow({
    title: 'LifeWise', width: 1440, height: 900, minWidth: 1000, minHeight: 700,
    backgroundColor: '#000000', show: false, autoHideMenuBar: true,
    icon: path.join(__dirname, 'assets', 'icon.png'),
    webPreferences: {
      partition: 'persist:lifewise-member', contextIsolation: true,
      nodeIntegration: false, sandbox: true, webSecurity: true,
      allowRunningInsecureContent: false, webviewTag: false,
      navigateOnDragDrop: false
    }
  });
  const contents = mainWindow.webContents;
  mainWindow.once('ready-to-show', () => mainWindow?.show());
  mainWindow.on('closed', () => { mainWindow = null; });
  contents.on('page-title-updated', event => { event.preventDefault(); mainWindow?.setTitle('LifeWise'); });
  contents.on('will-attach-webview', event => event.preventDefault());
  const guard = (event, url) => {
    if (classifyNavigation(url) === 'internal') return;
    event.preventDefault();
    openExternal(url);
  };
  contents.on('will-navigate', guard);
  contents.on('will-redirect', (event, url, _inPlace, isMainFrame) => { if (isMainFrame) guard(event, url); });
  contents.setWindowOpenHandler(({ url }) => {
    if (classifyNavigation(url) === 'internal') contents.loadURL(url).catch(() => {});
    else openExternal(url);
    return { action: 'deny' };
  });
  contents.on('did-fail-load', (_event, code, _description, _url, isMainFrame) => {
    if (isMainFrame && code !== -3) showLoadError();
  });
  contents.on('render-process-gone', () => showLoadError());
  mainWindow.loadURL(MEMBER_URL).catch(() => {});
}
async function showLoadError() {
  if (quitting || errorDialogOpen || !mainWindow || mainWindow.isDestroyed()) return;
  errorDialogOpen = true;
  mainWindow.show();
  try {
    const { response } = await dialog.showMessageBox(mainWindow, {
      type: 'warning', title: 'LifeWise', message: 'LifeWise could not load.',
      detail: 'Check your internet connection, then try again. Your saved sign-in has not been removed.',
      buttons: ['Try again', 'Close'], defaultId: 0, cancelId: 1
    });
    errorDialogOpen = false;
    if (!mainWindow || mainWindow.isDestroyed() || quitting) return;
    if (response === 0) mainWindow.loadURL(MEMBER_URL).catch(() => {});
    else mainWindow.close();
  } catch { errorDialogOpen = false; }
}
