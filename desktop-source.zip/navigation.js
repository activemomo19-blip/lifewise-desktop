'use strict';
const MEMBER_URL = 'https://my.lifewiseapp.com';
function classifyNavigation(raw) {
  try {
    const url = new URL(raw);
    if (url.username || url.password) return 'deny';
    if (url.origin === MEMBER_URL) return 'internal';
    if (['https:', 'http:', 'mailto:'].includes(url.protocol)) return 'external';
  } catch { /* Invalid and privileged protocols must never reach the OS shell. */ }
  return 'deny';
}
module.exports = { MEMBER_URL, classifyNavigation };
