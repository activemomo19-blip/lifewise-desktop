'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { classifyNavigation } = require('../navigation');
test('keeps only exact HTTPS member origin inside LifeWise', () => {
  for (const url of ['https://my.lifewiseapp.com', 'https://my.lifewiseapp.com/Schedule?day=monday', 'https://my.lifewiseapp.com/#login']) assert.equal(classifyNavigation(url), 'internal');
  for (const url of ['https://my.lifewiseapp.com.attacker.test', 'https://my.lifewiseapp.com:444/', 'https://discord.com', 'https://billing.stripe.com', 'https://lifewiseapp.com/contact']) assert.equal(classifyNavigation(url), 'external');
});
test('does not send privileged or malformed URLs to the system shell', () => {
  for (const url of ['javascript:alert(1)', 'file:///etc/passwd', 'data:text/html,test', 'ms-settings:test', 'not a URL', 'https://user:password@my.lifewiseapp.com']) assert.equal(classifyNavigation(url), 'deny');
});
